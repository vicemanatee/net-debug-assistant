#include "model_receivefileinthread.h"

model_receiveFileInThread::model_receiveFileInThread()
{

}
