#ifndef MODEL_RECEIVEFILEINTHREAD_H
#define MODEL_RECEIVEFILEINTHREAD_H

#include <QObject>

class model_receiveFileInThread : public QObject
{
    Q_OBJECT
public:
    model_receiveFileInThread();
};

#endif // MODEL_RECEIVEFILEINTHREAD_H
